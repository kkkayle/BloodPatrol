
export interface AnalysisResultVO {
    prob: number;
    csv_path: string;
    png_path: string;
}

export interface AnalysisResultDTO {

}
