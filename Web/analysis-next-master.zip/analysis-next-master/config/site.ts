export type SiteConfig = typeof siteConfig;

export const siteConfig = {
	name: "BloodPatrol",
	description: "BloodPatrol",
};
