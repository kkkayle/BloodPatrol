import axios, { InternalAxiosRequestConfig, AxiosResponse } from "axios";

export interface MyAxiosRequestConfig extends InternalAxiosRequestConfig {
    needToken?: boolean
}


const baseURL = process.env.NEXT_PUBLIC_BASE_URL

let requests: Function[] = [];

export const service = axios.create({
    timeout: 360000,
    baseURL: baseURL,
})

export const Method = {
    GET: 'get',
    POST: 'post',
    PUT: 'put',
    DELETE: 'delete',
    PATCH: 'patch'
};

export default function clientRequest<T>(options: {
    url: string,
    method: string,
    needToken: boolean,
    data?: any
}): Promise<AxiosResponse<T>> {
    return service(options);
}
