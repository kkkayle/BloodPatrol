'use client'

import {Card} from "@nextui-org/card";
import Image from "next/image";
import { useRouter } from "next/navigation";

export default function AnalysisCard({ text, routePath, imageUrl }: {
    text: string,
    routePath: string,
    imageUrl: string
}) {

    const router = useRouter()

    const onCardClick = () => {
        router.push(routePath)
    }

    return (
        <Card
            className="relative m-5 w-[300px] min-w-[300px] h-[168.75px] bg-white rounded-3xl"
            shadow="sm"
            isPressable
            onClick={onCardClick}
        >
            <Image priority={true} width={300} height={180} src={imageUrl} alt="analysis"/>
            <div
                className="text-xl font-bold text-white"
                style={{
                    position: 'absolute',
                    top: 25,
                    left: 10,
                    zIndex: 1
                }}
            >
                {text}
            </div>
        </Card>
    )
}
