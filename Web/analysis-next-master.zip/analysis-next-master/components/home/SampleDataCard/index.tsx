'use client'
import Image from "next/image";


export default function SampleDataCard({ imageUrl, link }: {
    imageUrl: string,
    link: string
}) {

    const SAMPLE_BASE_URL = process.env.NEXT_PUBLIC_SAMPLE_BASE_URL

    return (
        <Image
            onClick={() => window.open(`${SAMPLE_BASE_URL}${link}`, "blank_")}
            className="cursor-pointer"
            width={300}
            height={75}
            src={imageUrl}
            alt={'sampleData'}
        />
    )
}