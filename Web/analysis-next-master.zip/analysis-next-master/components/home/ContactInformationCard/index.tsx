'use client'
import {Card} from "@nextui-org/card";


export default function ContactInformationCard() {
    return (
        <Card radius="none" className="self-end flex flex-row justify-center w-full bg-[#20558A] h-[200px] text-white pt-5">
            <div className="flex flex-row mr-10">
                <div className="text-base font-bold mr-2">
                    Address:
                </div>
                <div className="flex-col w-[260px]">
                    <div>
                        Wenzhou University of Technology
                    </div>
                    <div>
                        No. 1 Jingguang Avenue, Chaoshan Higher Education Park, Ouhai District, Wenzhou City, Zhejiang Province.
                    </div>
                </div>
            </div>
            <div className="flex flex-row">
                <div className="text-base font-bold mr-2">
                    Contact Information:
                </div>
                <div>
                    Jinhang.wei23@gmail.com
                </div>
            </div>
        </Card>
    )
}
