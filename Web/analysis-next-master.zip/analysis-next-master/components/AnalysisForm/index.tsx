'use client'
import { Card, CardBody } from "@nextui-org/card";
import { Image } from "@nextui-org/image";
import { Button } from "@nextui-org/button";
import {Slider, SliderValue} from "@nextui-org/slider";
import { Input } from "@nextui-org/input";
import { Chip } from "@nextui-org/chip";
import { useDispatch } from "react-redux";
import { Select, SelectItem } from "@nextui-org/select";
import React, { useState, useRef } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { submitAnalysis } from "@/requests/analysis";
import { setModal } from "@/store/modal/modalSlice";
import { setAnalysisImageModal } from "@/store/analysisImageModal/analysisImageModal";
import AnalysisImageModal from "@/components/AnalysisImageModal";


export default function AnalysisForm() {
    const bloodCancerTypeList: string[] = ["CLL", "B-ALL"]
    const searchParams = useSearchParams()
    const router = useRouter()
    const queryBloodCancerType = searchParams.get("blood_cancer_type") || "CLL"

    const fileUploadRef = useRef<HTMLInputElement | null>(null)


    const [formValue, setFormValue] = useState<{
        bloodCancerType: string
        numParts: SliderValue
        begin: number | null
        end: number | null
        file: File | null
    }>(
        {
            bloodCancerType: bloodCancerTypeList.includes(queryBloodCancerType) ? queryBloodCancerType : "CLL",
            numParts: 60,
            begin: null,
            end: null,
            file: null
        }
    )
    const [isSubmitting, setIsSubmitting] = useState<boolean>(false)
    const [imageUrl, setImageUrl] = useState<string>("./analyzed_heatmap.png")
    const [resUrl, setResUrl] = useState<string | null>(null)
    const [prob, setProb] = useState<number>(0)

    const dispatch = useDispatch()

    const cancelFileSelect = () => {
        if (fileUploadRef.current) {
            // @ts-ignore
            fileUploadRef.current.value = null;
        }
        setResUrl(null)
        setProb(0)
        setImageUrl('./analyzed_heatmap.png')
    }

    const submit = () => {
        console.log(formValue)
        if (!formValue.file) {
            dispatch(setModal({
                title: "Hint",
                content: "Please select a file",
                isOpen: true
            }))
            return
        }
        setIsSubmitting(true)
        submitAnalysis({
            blood_cancer_type: formValue.bloodCancerType,
            begin: formValue.begin,
            end: formValue.end,
            num_parts: Array.isArray(formValue.numParts) ? formValue.numParts[0] : formValue.numParts,
            file: formValue.file
        }).then(
            res => {
                console.log(res.data.data)
                setImageUrl(res.data.data.png_path)
                setResUrl(res.data.data.csv_path)
                setProb(res.data.data.prob)
            }
        ).catch(
            e => {
                dispatch(setModal({
                    isOpen: true,
                    title: "Error",
                    content: "Analysis failure"
                }))
                cancelFileSelect()
                console.log(e)
            }
        ).finally(
            () => setIsSubmitting(false)
        )
    }

    return (
        <div className="flex justify-center items-center h-full w-full min-w-[700px] mt-20">
            <AnalysisImageModal/>
            <Card className="flex flex-col items-center w-[80%] h-[600px] max-w-[820px] min-w-[980px] p-5 box-border">
                <div
                  className="self-start font-bold"
                >
                    <Button
                        size="sm"
                        variant="light"
                        onClick={() => router.push("/")}
                    >
                        {"Back"}
                    </Button>
                </div>
                <div className="text-5xl font-bold mb-8">
                    Analysis
                </div>
                <div className="flex flex-row justify-center">
                    <div className="flex flex-col items-center mr-5">
                        <div className="w-[360px] h-[320px] mb-3">
                            <Image
                                className="object-contain cursor-pointer"
                                src={imageUrl}
                                alt={"res_image"}
                                onClick={() => {
                                    dispatch(setAnalysisImageModal({
                                        imageUrl: imageUrl || undefined,
                                        isOpen: true
                                    }))
                                }}
                            />
                        </div>
                        <div className="h-[40px]">
                            {resUrl ?
                                <div className="flex flex-col items-center w-[360px]">
                                    <Card className="w-[360px] h-[45px] flex flex-row justify-center items-center bg-[#556fe6] mb-3">{`Prob: ${prob.toFixed(3)}`}</Card>
                                    <Button
                                        size="sm"
                                        className="w-[360px]"
                                        color="primary"
                                        variant="bordered"
                                        onClick={() => window.open(resUrl, "_blank")}
                                    >
                                        Download Result
                                    </Button>
                                </div>: <></>
                            }
                        </div>
                    </div>
                    <div className="flex flex-col items-center">
                        <Slider
                            size="lg"
                            label="Num Parts"
                            value={formValue.numParts}
                            onChange={(value) => {
                                setFormValue({
                                    ...formValue,
                                    numParts: value
                                })
                            }}
                            classNames={{
                                base: "max-w-md gap-3",
                                track: "border-s-blue-100",
                                filler: "bg-gradient-to-r from-blue-100 to-blue-500"
                            }}
                            renderThumb={(props) => (
                                <div
                                    {...props}
                                    className="group p-1 top-1/2 bg-background border-small border-default-200 dark:border-default-400/50 shadow-medium rounded-full cursor-grab data-[dragging=true]:cursor-grabbing"
                                >
                                    <span className="transition-transform bg-gradient-to-br shadow-small from-blue-100 to-blue-500 rounded-full w-5 h-5 block group-data-[dragging=true]:scale-80" />
                                </div>
                            )}
                        />
                        <Select
                            label="Blood Cancer Type"
                            variant="bordered"
                            placeholder="Select blood cancer type"
                            selectedKeys={[formValue.bloodCancerType]}
                            className="w-[400px] mt-3"
                            onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setFormValue({
                                ...formValue,
                                bloodCancerType: e.target.value
                            })}
                        >
                            {bloodCancerTypeList.map((item) => (
                                <SelectItem key={item} value={item}>
                                    {item}
                                </SelectItem>
                            ))}
                        </Select>

                        <div className="flex flex-row items-center justify-between w-[400px] mt-3">
                            <Card
                                className="w-[250px]"
                            >
                                <CardBody
                                    className="min-h-[48px]"
                                >
                                    {formValue.file ?
                                        <Chip
                                            variant="flat"
                                            onClose={() => {
                                                cancelFileSelect()
                                                setFormValue({
                                                    ...formValue,
                                                    file: null
                                                })
                                            }}
                                        >
                                            {formValue.file.name}
                                        </Chip>
                                        :
                                        <p
                                            className={
                                                formValue.file ? "text-green-600" : ""
                                            }
                                        >
                                            The file separator must be /t
                                        </p>
                                    }

                                </CardBody>
                            </Card>
                            <input
                                type="file"
                                ref={fileUploadRef}
                                style={{
                                    display: "none"
                                }}
                                onChange={(e) => {
                                    console.log(e.target.files?.[0])
                                    console.log(typeof e.target.files?.[0])
                                    if (e.target.files?.[0]) {
                                        setFormValue({
                                            ...formValue,
                                            file: e.target.files[0]
                                        })
                                    }
                                }}
                                accept=".txt"
                            />
                            <Button
                                size="lg"
                                onClick={() => {
                                    cancelFileSelect()
                                    fileUploadRef.current?.click()
                                }}
                            >
                                Select File
                            </Button>
                        </div>
                        <div className="flex flex-row items-center justify-between w-[400px] mt-3">
                            <Input
                                size="sm"
                                className="w-[180px]"
                                type="number"
                                variant="flat"
                                label="begin"
                                onValueChange={(value) => setFormValue({
                                    ...formValue,
                                    begin: parseInt(value)
                                })}
                            />
                            <Input
                                size="sm"
                                className="w-[180px]"
                                type="number"
                                variant="flat"
                                label="end"
                                onValueChange={(value) => setFormValue({
                                    ...formValue,
                                    end: parseInt(value)
                                })}
                            />
                        </div>
                        <Button
                            size="lg"
                            className="mt-5 w-[400px]"
                            color="primary"
                            variant="shadow"
                            isLoading={isSubmitting}
                            onClick={submit}
                        >
                            Submit
                        </Button>
                    </div>
                </div>
            </Card>
        </div>
    )
}
