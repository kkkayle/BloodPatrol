'use client'
import { Modal, ModalHeader, ModalBody, ModalContent, ModalFooter } from "@nextui-org/modal";
import { Image } from "@nextui-org/image";
import { Button } from "@nextui-org/button";
import { useSelector, useDispatch } from "react-redux";
import { setAnalysisImageModal } from "@/store/analysisImageModal/analysisImageModal";
import {RootState} from "@/store";

export default function AnalysisImageModal() {

    const analysisImageModal = useSelector((state: RootState) => state.analysisImageModal)
    const dispatch = useDispatch()

    const onClose = () => {
        dispatch(setAnalysisImageModal({
            isOpen: false,
            imageUrl: undefined
        }))
    }

    return (
        <Modal
            isOpen={analysisImageModal.isOpen}
            onClose={onClose}
            size="3xl"
        >
            <ModalContent>
                <ModalHeader className="flex flex-col gap-1">Image</ModalHeader>
                <ModalBody>
                    <Image
                        src={analysisImageModal.imageUrl}
                        alt="image"
                    />
                </ModalBody>
                <ModalFooter>
                    <Button color="danger" variant="light" onPress={onClose}>
                        Close
                    </Button>
                    <Button
                        color="primary"
                        onClick={() => {
                            window.open(analysisImageModal.imageUrl, "blank_")
                        }}
                    >
                        Download
                    </Button>
                </ModalFooter>
            </ModalContent>
        </Modal>
    )
}
