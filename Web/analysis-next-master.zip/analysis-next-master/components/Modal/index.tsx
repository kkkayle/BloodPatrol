'use client'
import { Modal as NextUIModal, ModalHeader, ModalBody, ModalContent, ModalFooter } from "@nextui-org/modal";
import { Button } from "@nextui-org/button";
import { useSelector, useDispatch } from "react-redux";
import { setModal } from "@/store/modal/modalSlice";
import {RootState} from "@/store";

export default function Modal() {

    const modal = useSelector((state: RootState) => state.modal)
    const dispatch = useDispatch()

    const close = () => {
        dispatch(setModal({
            title: "",
            content: "",
            isOpen: false
        }))
    }

    return(
        <NextUIModal
            isOpen={modal.isOpen}
            onClose={() => close()}
            backdrop="blur"
        >
            <ModalContent>
                <ModalHeader className="flex flex-col gap-1">{modal.title}</ModalHeader>
                <ModalBody>
                    {modal.content}
                </ModalBody>
                <ModalFooter>
                    <Button
                      color="primary"
                      onClick={() => close()}
                    >
                        OK
                    </Button>
                </ModalFooter>
            </ModalContent>
        </NextUIModal>
    )
}