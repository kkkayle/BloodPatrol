'use client'
import { Link } from "@nextui-org/link"
import { useRouter } from "next/navigation";

export default function HeaderButtons() {

    const router = useRouter()

    return (
        <div className="flex flex-row">
            <Link onClick={() => router.push("/")} className="cursor-pointer">Home</Link>
            <Link
                className="ml-3 cursor-pointer"
                onClick={() => window.open("https://github.com/kkkayle/BloodPatrol")}
            >
                Github
            </Link>
            <Link
                className="ml-3 cursor-pointer"
                onClick={() => window.open("https://drive.google.com/drive/folders/1VcmDOdBbG46ILRd99TM2ZsZHBpcMazZ6")}
            >
                Dataset
            </Link>
            <Link
                className="ml-3 cursor-pointer"
                onClick={() => window.open('/doc/help_documentation.docx')}
            >
                Help
            </Link>
        </div>
    )
}
