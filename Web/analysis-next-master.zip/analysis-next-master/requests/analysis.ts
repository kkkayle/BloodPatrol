import request, { Method } from "@/utils/request";
import { AnalysisResultVO } from "@/types/analysisTypes";
import { ResData } from "@/types/requestTypes";


export function submitAnalysis(params: {
    blood_cancer_type: string
    begin: number | null
    end: number | null
    num_parts: number | null
    file: File
}) {
    const formData = new FormData();
    for (let [key, value] of Object.entries(params)) {
        if (value !== undefined && value !== null) {
            // @ts-ignore
            formData.append(key, value)
        }
    }
    return request<ResData<AnalysisResultVO>>({
        url: "/api/analysis",
        method: Method.POST,
        data: formData,
        needToken: true
    })
}
