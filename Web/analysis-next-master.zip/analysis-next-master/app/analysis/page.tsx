import AnalysisForm from "@/components/AnalysisForm";

export default function Analysis() {

    return (
        <div className="w-full">
            <AnalysisForm/>
        </div>
    )
}
