import { Card, CardBody, CardFooter, CardHeader } from "@nextui-org/card";
import Image from "next/image";
import AnalysisCard from "@/components/home/AnalysisCard";
import ContactInformationCard from "@/components/home/ContactInformationCard";
import SampleDataCard from "@/components/home/SampleDataCard";

export default function Home() {
	return (
		<div className="flex w-full flex-col items-center h-full box-border pt-10">
			<div className="flex justify-center items-center">
				<div className="flex flex-row justify-between w-[950px]">
					<div className="flex flex-col w-[500px]">
						<div className="font-bold text-2xl mt-2">
							BloodPatrol : An effective dynamic monitoring and diagnostic model for blood cancer
						</div>
						<div>
							The BloodPatrol leverages flow cytometry data to accurately diagnose blood cancer using a Transformer-based encoder and an intelligent feature weight fusion module.
						</div>
					</div>
					<Card className="h-[180px] w-[300px]">
						<CardHeader className="text-xl font-bold">
							News
						</CardHeader>
						<CardBody>
							<div className="flex-grow flex flex-col items-center">
								<div>
									Initial version released. <br/>
									2023.11.20
								</div>
							</div>
						</CardBody>
					</Card>
				</div>
			</div>
			<div className="flex justify-center items-center mt-20">
				<div className="flex flex-row justify-center items-center">
					<AnalysisCard
						imageUrl={'/cll_button.png'}
						text=""
						routePath="/analysis?blood_cancer_type=CLL"
					/>
					<div className="flex flex-col">
						<SampleDataCard
							imageUrl={'/b_all_sample_data_button.png'}
							link="/B-ALL_Sample.txt"
						/>
						<SampleDataCard
							imageUrl='/cll_sample_data_button.png'
							link="/CLL_Sample.txt"
						/>
					</div>
					<AnalysisCard
						imageUrl={'/b_all_button.png'}
						text=""
						routePath="/analysis?blood_cancer_type=B-ALL"
					/>
				</div>
			</div>
			<div className="flex flex-col justify-end self-end w-full flex-grow">
				<ContactInformationCard/>
			</div>
		</div>
	);
}
