import "@/styles/globals.css";
import { Metadata } from "next";
import { siteConfig } from "@/config/site";
import { fontSans } from "@/config/fonts";
import { Providers } from "./providers";
import Modal from "@/components/Modal";
import clsx from "clsx";
import {Card} from "@nextui-org/card";
import HeaderButtons from "@/components/HeaderButtons";
import ContactInformationCard from "@/components/home/ContactInformationCard";

export const metadata: Metadata = {
	title: {
		default: siteConfig.name,
		template: `%s - ${siteConfig.name}`,
	},
	description: siteConfig.description,
	themeColor: [
		{ media: "(prefers-color-scheme: light)", color: "white" },
		{ media: "(prefers-color-scheme: dark)", color: "black" },
	],
	icons: {
		icon: "/favicon.ico",
		shortcut: "/favicon-16x16.png",
		apple: "/apple-touch-icon.png",
	},
};

export default function RootLayout({
	children,
}: {
	children: React.ReactNode;
}) {
	return (
		<html lang="en" suppressHydrationWarning>
			<head />
			<body
				className={clsx(
					"min-h-screen bg-background font-sans antialiased",
					fontSans.variable
				)}
			>
				<Providers themeProps={{ attribute: "class", defaultTheme: "light" }}>
					<div className="flex w-full h-screen flex-col min-w-[1000px]">
						<div className="w-full">
							<Card
								className="flex flex-row justify-between items-center w-full h-[60px] pl-10 pr-10"
								radius="none"
							>
								<div className="text-base font-black">
									BloodPatrol
								</div>
								<HeaderButtons/>
							</Card>
						</div>
						<div className="flex-grow">
							{children}
						</div>
						<Modal/>
					</div>
				</Providers>
			</body>
		</html>
	);
}
