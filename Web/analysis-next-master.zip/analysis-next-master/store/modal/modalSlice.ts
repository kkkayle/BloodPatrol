import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface ModalType {
    isOpen: boolean
    content: string
    title: string
}

const initialState: ModalType = {
    isOpen: false,
    content: "",
    title: ""
}

export const modalSlice = createSlice({
    name: "modalSlice",
    initialState,
    reducers: {
        setModal: (state, action: PayloadAction<ModalType>) => {
            return action.payload
        }
    }
})

export const { setModal } = modalSlice.actions

export default modalSlice.reducer
