import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface AnalysisImageModalState {
    isOpen: boolean
    imageUrl: string | undefined
}

const initialState: AnalysisImageModalState = {
    isOpen: false,
    imageUrl: undefined
}

export const analysisImageModalSlice = createSlice({
    name: "analysisImageModalSlice",
    initialState,
    reducers: {
        setAnalysisImageModal: (state, action: PayloadAction<AnalysisImageModalState>) => {
            return action.payload
        }
    }

})

export const { setAnalysisImageModal } = analysisImageModalSlice.actions

export default analysisImageModalSlice.reducer