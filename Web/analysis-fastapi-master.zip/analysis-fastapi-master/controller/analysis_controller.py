from fastapi import APIRouter, Depends, Form
from model import AnalysisDTO
from service import AnalysisService
from model import ResData, AnalysisVO
import base64
from utils import file_to_base64

analysis_router = APIRouter()


@analysis_router.post("/api/analysis")
async def analysis(blood_cancer_type=Form(),
                   begin=Form(None),
                   end=Form(None),
                   num_parts=Form(),
                   file=Form()
                   , analysis_service: AnalysisService = Depends()):
    res = await analysis_service.analysis(blood_cancer_type=blood_cancer_type,
                                          begin=begin,
                                          end=end,
                                          num_parts=num_parts,
                                          file=file)
    print(res)
    # csv_base64 = file_to_base64("./data/analyzed.csv")
    # image_base64 = file_to_base64("./data/heatmap.png")
    # print(image_base64)
    return ResData.success(res.to_dic())
