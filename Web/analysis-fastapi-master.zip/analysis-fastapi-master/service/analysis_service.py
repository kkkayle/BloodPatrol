from fastapi import Depends, UploadFile
import os
import redis
import uuid
from core import get_redis
from core import SAVE_DATA_PATH, DOMAIN
from utils.analysis.cytome_analysis import run_model
from model import ModelResDTO


class AnalysisService:

    def __init__(self, redis: redis.Redis = Depends(get_redis)):
        self.redis = redis

    async def analysis(self, blood_cancer_type: str,
                       begin: int,
                       end: int,
                       num_parts: int,
                       file: UploadFile):
        files = await file.read()
        os.makedirs(SAVE_DATA_PATH, exist_ok=True)
        filename = uuid.uuid4().__str__().replace("-", "") + file.filename
        with open(os.path.join(SAVE_DATA_PATH, filename), "wb") as f:
            f.write(files)

        result = run_model(blood_cancer_type=blood_cancer_type,
                           file_name=f"{SAVE_DATA_PATH}/{filename}",
                           # begin=int(begin),
                           # end=int(end),
                           num_parts=int(num_parts))
        return ModelResDTO(
            prob=float(result[0]),
            csv_path=f"{DOMAIN}/static/{os.path.basename(result[1])}",
            png_path=f"{DOMAIN}/static/{os.path.basename(result[2])}"
        )
