import torch
from torch import nn
import torch.nn.functional as F


class WeightNetwork(nn.Module):
    def __init__(self, filed_size, reduction_ratio=3):
        super(WeightNetwork, self).__init__()
        self.reduction_size = max(1, filed_size // reduction_ratio)
        self.excitation = nn.Sequential(
            nn.Linear(filed_size, self.reduction_size, bias=False),
            nn.ReLU(),
            nn.Linear(self.reduction_size, filed_size, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, inputs):
        Z = torch.mean(inputs, dim=-1, out=None)
        A = self.excitation(Z)
        V = torch.mul(inputs, torch.unsqueeze(A, dim=-1))
        return V


import torch.nn as nn


class ResidualConv1D(nn.Module):
    def __init__(self, dim_1, dim_2, dim_3):
        super(ResidualConv1D, self).__init__()

        # First convolution layer
        self.conv1 = nn.Sequential(
            nn.Conv1d(in_channels=dim_1, out_channels=dim_2, kernel_size=3, padding=1),
            nn.ReLU()
        )

        # Second convolution layer
        self.conv2 = nn.Sequential(
            nn.Conv1d(in_channels=dim_2, out_channels=dim_2, kernel_size=3, padding=1),
            nn.ReLU()
        )

        # Third convolution layer
        self.conv3 = nn.Sequential(
            nn.Conv1d(in_channels=dim_2, out_channels=dim_3, kernel_size=3, padding=1),
            nn.ReLU()
        )

    def forward(self, x):
        out1 = self.conv1(x)
        out2 = self.conv2(out1) + out1
        out3 = self.conv3(out2)
        return out3


class PolyLoss(nn.Module):
    def __init__(self, DEVICE, weight_loss=None, epsilon=1.0):
        super(PolyLoss, self).__init__()
        self.CELoss = nn.CrossEntropyLoss(weight=weight_loss, reduction='none')
        self.epsilon = epsilon
        self.DEVICE = DEVICE

    def forward(self, predicted, labels):
        batch_size = labels.shape[0]
        one_hot = torch.zeros((batch_size, 2), device=self.DEVICE).scatter_(
            1, labels.to(torch.int64), 1)
        pt = torch.sum(one_hot * F.softmax(predicted, dim=1), dim=-1)
        ce = self.CELoss(predicted, labels)
        poly1 = ce + self.epsilon * (1 - pt)
        return torch.mean(poly1)


class Model(nn.Module):
    def __init__(self, class_weight, dataset, lr=0.0001, epoch_size=185):
        super().__init__()
        self.in_feats_dim = 11 if dataset == 'B-ALL' else 16
        self.nhead = 11 if dataset == 'B-ALL' else 4
        self.transformer = nn.TransformerEncoderLayer(d_model=self.in_feats_dim, nhead=self.nhead)

        self.encoder = nn.TransformerEncoder(self.transformer, num_layers=1)
        self.conv_layers = ResidualConv1D(self.in_feats_dim, 32, self.in_feats_dim)

        self.conv_pool = ResidualConv1D(self.in_feats_dim, self.in_feats_dim, 4)

        self.step_size_up = 5
        self.decoder = nn.Sequential(
            nn.Linear(400, 256),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(128, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 2),
        )

        self.ploy_loss = PolyLoss(DEVICE=torch.device("cuda" if torch.cuda.is_available() else "cpu"),
                                  weight_loss=class_weight)
        self.val_out = []
        self.test_out = []
        self.desired_output_dim = 100
        self.layer_norm = nn.LayerNorm(self.in_feats_dim)
        self.cnn_weight = WeightNetwork(100)
        self.ts_weight = WeightNetwork(100)

    def forward(self, x):
        x = self.layer_norm(x)
        encode = self.encoder(x)
        encode_pooled = self.max_pooling(encode)
        ts_pooled = self.ts_weight(encode_pooled) * 0.5 + encode_pooled * 0.5
        pooled = self.conv_pool(ts_pooled.permute(0, 2, 1)).permute(0, 2, 1)
        out = self.decoder(pooled.reshape(x.shape[0], -1))
        return out

    def max_pooling(self, x):
        x = x.permute(0, 2, 1)

        pooled = F.adaptive_max_pool1d(x, output_size=self.desired_output_dim)
        pooled = pooled.permute(0, 2, 1)

        return pooled
