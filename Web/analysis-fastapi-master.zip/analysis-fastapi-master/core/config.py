from dotenv import load_dotenv
import os

load_dotenv()

SAVE_DATA_PATH = os.environ.get("SAVE_DATA_PATH")
DOMAIN = os.environ.get("DOMAIN")
ORIGINS = os.environ.get("ORIGINS").split(",")
