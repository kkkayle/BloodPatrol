from pydantic import BaseModel


class ModelResDTO(BaseModel):
    prob: float
    csv_path: str
    png_path: str

    def to_dic(self):
        return {
            "prob": self.prob,
            "csv_path": self.csv_path,
            "png_path": self.png_path
        }
