from pydantic import BaseModel


class AnalysisVO(BaseModel):
    initial_prob: float
    csv_url: str
    image_url: str

    def to_dic(self):
        return {
            "initial_prob": self.initial_prob,
            "csv_url": self.csv_url,
            "image_url": self.image_url
        }
