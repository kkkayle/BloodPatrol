from pydantic import BaseModel
from fastapi import UploadFile


class AnalysisDTO(BaseModel):
    blood_cancer_type: str
    begin: int
    end: int
    num_parts: int
    file: UploadFile

