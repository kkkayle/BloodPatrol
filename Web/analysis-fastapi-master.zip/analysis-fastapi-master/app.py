from fastapi import FastAPI, Request, Depends
from dotenv import load_dotenv
from controller import analysis_router
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from core import ORIGINS, SAVE_DATA_PATH


load_dotenv()
Request.max_content_length = 100 * 1024 * 1024  # 100MB

app = FastAPI()
app.include_router(analysis_router)
app.mount("/static",
          StaticFiles(directory=SAVE_DATA_PATH),  name="static")

app.add_middleware(
    CORSMiddleware,
    allow_origins=ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

#
# @app.post("/analysis")
# def analysis():


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app="app:app", host="0.0.0.0", port=8000, workers=4)